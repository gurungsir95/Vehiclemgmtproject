package com.app.vehicle.mgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehiclemgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehiclemgmtApplication.class, args);
	}

}
