package com.app.vehicle.dto;

import java.util.UUID;
public class VehicleResponseDto {
 private UUID uid;
 public UUID getUid() {
  return uid;
 }
 public void setUid(UUID uid) {
  this.uid = uid;
 }
 
}