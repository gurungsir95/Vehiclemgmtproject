/**
 * 
 */
/**
 * @author Lakshmi
 *
 */
package com.app.vehicle.dto;